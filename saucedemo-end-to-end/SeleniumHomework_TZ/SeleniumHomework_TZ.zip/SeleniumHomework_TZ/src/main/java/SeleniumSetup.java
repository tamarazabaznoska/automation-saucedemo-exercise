import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

public class SeleniumSetup {


    private static WebDriver driver;

    private static WebDriverWait wait;


    public static void setup() {
        System.setProperty("webdriver.chrome.driver", "src/main/resources/chromedriver.exe");
        driver = new ChromeDriver();
        driver.manage().window().maximize();
        driver.get("https://www.saucedemo.com/");

        wait = new WebDriverWait(driver, 60);
    }

    public static String getCurrentUrl() {
        return driver.getCurrentUrl();
    }

    public static void logMeIn() {
        WebElement usernameTxt = driver.findElement(By.xpath("//*[@id=\"user-name\"]"));
        usernameTxt.sendKeys("standard_user");

        WebElement passwordTxt = driver.findElement(By.xpath("//*[@id=\"password\"]"));
        passwordTxt.sendKeys("secret_sauce");

        WebElement loginBtn = driver.findElement(By.xpath("//*[@id=\"login-button\"]"));
        loginBtn.click();
    }

    public static void addProductsToCart() {
        WebElement addToCart1Btn = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//*[@id=\"add-to-cart-sauce-labs-backpack\"]")));
        addToCart1Btn.click();

        WebElement addToCart2Btn = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//*[@id=\"add-to-cart-sauce-labs-bike-light\"]")));
        addToCart2Btn.click();

        WebElement addToCart3Btn = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//*[@id=\"add-to-cart-sauce-labs-bolt-t-shirt\"]")));
        addToCart3Btn.click();

        WebElement ShoppingIconBtn = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//*[@id=\"shopping_cart_container\"]/a")));
        ShoppingIconBtn.click();

        WebElement checkoutBtn = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//*[@id=\"checkout\"]")));
        checkoutBtn.click();
    }

    public static void checkoutInformation() {
        WebElement firstNameTXTEW = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//*[@id=\"first-name\"]")));
        firstNameTXTEW.sendKeys("Tamara");

        WebElement lastNameTXTEW = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//*[@id=\"last-name\"]")));
        lastNameTXTEW.sendKeys("Zabaznoska");

        WebElement zipPostalCodeTXTEW = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//*[@id=\"postal-code\"]")));
        zipPostalCodeTXTEW.sendKeys("1000");

        WebElement continueBtn = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//*[@id=\"continue\"]")));
        continueBtn.click();

        WebElement finishBtn = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//*[@id=\"finish\"]")));
        finishBtn.click();
    }

    public static String assertConfirmationMessage() {
        WebElement confirmationMsg = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//*[@id=\"checkout_complete_container\"]/h2")));
        return confirmationMsg.getText();
    }

    public static void end() {
        driver.quit();
    }
}




