import org.testng.Assert;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.*;

public class Test {

    @BeforeClass
    public void beforeClass() {
        SeleniumSetup.setup();
    }

    @org.testng.annotations.Test(priority = 10)
    public void testForVerifyingUserLandingOnHomePage(){
        Assert.assertEquals(SeleniumSetup.getCurrentUrl(), "https://www.saucedemo.com/");
    }

    @org.testng.annotations.Test(priority = 20)
    public void testForLogInUser() {
        SeleniumSetup.logMeIn();
    }

    @org.testng.annotations.Test(priority = 30)
    public void testForAddingProductToTheCart() {
        SeleniumSetup.addProductsToCart();
    }

    @org.testng.annotations.Test(priority = 40)
    public void testForCheckoutInformation() {
        SeleniumSetup.checkoutInformation();
    }

    @org.testng.annotations.Test(priority = 50)
    public void testForValidatingConfirmationMessage() {
        Assert.assertEquals(SeleniumSetup.assertConfirmationMessage(), "Thank you for your order!");
    }

    @AfterClass
    public void afterClass() {
        SeleniumSetup.end();
    }

}
